.. automodule:: scipy.stats._result_classes
   :no-members:
   :no-inherited-members:
   :no-special-members:

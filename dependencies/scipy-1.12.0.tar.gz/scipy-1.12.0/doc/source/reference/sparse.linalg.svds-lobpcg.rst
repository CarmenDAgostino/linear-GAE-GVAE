.. _sparse.linalg.svds-lobpcg:

svds(solver='lobpcg')
----------------------------------------

.. scipy-optimize:function:: scipy.sparse.linalg.svds
   :impl: scipy.sparse.linalg._eigen._svds_doc._svds_lobpcg_doc
   :method: lobpcg

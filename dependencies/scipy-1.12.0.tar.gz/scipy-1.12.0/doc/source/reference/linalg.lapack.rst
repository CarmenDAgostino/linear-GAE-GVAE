.. automodule:: scipy.linalg.lapack
   :no-members:
   :no-inherited-members:
   :no-special-members:
